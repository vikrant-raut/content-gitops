![la logo](https://user-images.githubusercontent.com/42839573/67322755-818e9400-f4df-11e9-97c1-388bf357353d.png)

### Linux Academy Course Repository
### Hands-On GitOps

This repository is a resource provided for Linux Academy students taking the hands-on GitIOps course.
